MID = ""
MK = ""